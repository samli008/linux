docker run -d --net=host --name=dhcp --restart=always \
-e IP=192.168.30.100 \
-v /root/dhcp:/etc/dhcp:ro \
-v /root/dhcp:/tftpboot:ro \
-p 67:67 -p 67:67/udp -p 69:69/udp \
pxedock
